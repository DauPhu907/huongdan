var fetch = global.nodemodule["node-fetch"];

var HD_get = function HD_get(type, data) {
	(async function () {
		var returntext = `Chào mừng bạn đã quay trở lại\nBạn có thể bỏ ra 3s để xem hướng dẫn nay\nĐây là một con bot để tương tác với nó bạn hãy dùng dấu lệnh (/)\nLưu ý : Dấu lệnh này có thể thay đổi tùy vào con bot\nĐể biết toàn bộ lệnh bạn hãy dùng /help ( trang số )\nSau khi /help lần đầu bạn hãy để ý cuối câu chat của bot Trang : số/số\nVD : 1/4 số 1 ở đây ám chỉ đang ở trang 1 còn số 4 tứ là 4 trang vậy bot này có 4 trang lệnh\nSố trang lệnh có thể thay đổi tùy thuộc vào số lượng Plugins cài vào bot\nBạn không hiểu lệnh gì ?\nà không sao bạn có thể dùng lệnh /help < tên lệnh bạn không hiểu >\nLúc này bot sẽ trả lời bạn lệnh này hoạt động như này nếu bạn không hiểu bạn hãy call cho admin bằng lệnh /calladmin < văn bản > để admin truy cập và giúp đỡ bạn hoặc bạn cũng có thể nhờ bạn bè trợ giúp trong trường hợp bạn bè bạn biết dùng họ có thể hướng dẫn bạn\nNhững trường hợp lệnh đặc biệt\nThường sảy ra khi cá lệnh đó dóng vai trò cực quan trọng trong việc chuyển hóa và sử dụng tài nghuyên lệnh trong bot lúc này bạn chỉ còn cách là /help < lệnh đặc biệt > bạn đừng lo lệnh đặc biệt đa phần sẽ hướng dẫn cụ thể hơn cho bạn hiểu ^^\nBot bị lỗi thì sao ak\nĐừng lo đây chỉ là lỗi tạm thời sẽ được fix sớm thôi\nNhưng trong trường hợp đang dùng mà bị lỗi bạn hãy lập tức báo cho người có chuyên một hoặc dùng lệnh /calladmin < văn bản > để đc sửa và sử lý kịp thời\nBạn đang có ý định dùng /kick khoan hày dừng tay\ntrước khi dùng bạn hãy kiểm tra xem bot có quyền quản trị không, nếu bạn dùng khi bot không có quyền quản trị thì khong sao\nNhưng nếu bạn dùng khi bot có quyền thì xác định ra đảo nha\nCảm ơn bạn đã đọc hướng dẫn này\nChúc bạn sử dụng vui vẻ <3\nLiên hệ admin tại : catheroteam@outlook.com.vn`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	HD_get: HD_get
}